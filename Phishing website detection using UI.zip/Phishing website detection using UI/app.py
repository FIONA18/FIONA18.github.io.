from flask import Flask,render_template,request,url_for,redirect,session,flash

import FeatureExtraction
import pickle
from functools import wraps
import datetime
from datetime import timedelta,datetime

app = Flask(__name__)
app.secret_key="fiona"
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('You need to login')
            return redirect(url_for('login'))
    return wrap


@app.route('/login',methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            session['logged_in']=True
            flash('You have logged in')
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@app.route('/')
def index():
    return render_template("login.html")

@app.route('/home')
@login_required
def home():
    return render_template("home.html")

@app.route('/about')
@login_required
def about():
    return render_template("about.html")

@app.route('/logout')
@login_required
def logout():
    session.pop('logged_in',None)
    flash('You have logged out')
    return render_template("login.html")

@app.route('/getURL',methods=['GET','POST'])
def getURL():
    if request.method == 'POST':
        url = request.form['url']
        print(url)
        data = FeatureExtraction.getAttributess(url)
        feature = open("features.txt","w")
        feature.write(str(data[0:1]))
        # print(data)
        #LRmodel = pickle.load(open('finalized_model.sav', 'rb'))
        LRmodel = pickle.load(open('LRModel3.sav', 'rb'))
        RFmodel = pickle.load(open('RandomForestModel2.sav', 'rb'))
        DTmodel=pickle.load(open('DecisionTreeModel.sav','rb'))
        print("model loaded") #itime = datetime.now()
        predicted_value_LR=LRmodel.predict(data)#ftime = datetime.now()
        predicted_value_RF=RFmodel.predict(data)#itime1 = datetime.now()
        predicted_value_DT=DTmodel.predict(data)#ftime1 = datetime.now()#print((ftime1-itime1).microseconds)
        print("predicted")
        print(predicted_value_LR)
        print(predicted_value_RF)
        print(predicted_value_DT)
        if (predicted_value_LR==0 and predicted_value_RF==0) or (predicted_value_RF==0 and predicted_value_DT==0) or (predicted_value_DT==0 and predicted_value_LR==0):    
            value = "Legitimate"
            return render_template("home.html",error=value)
        else:
            value = "Phishing"
            return render_template("home.html",error=value)
if __name__ == "__main__":
    app.run(debug=True)
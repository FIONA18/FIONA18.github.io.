import pandas as pd


# ## Collection of Data

# In[2]:


legitimate_urls = pd.read_csv("legitimate-urls.csv")
phishing_urls = pd.read_csv("phishing-urls.csv")

# In[3]:


print(len(legitimate_urls))
print(len(phishing_urls))


# ## Data PreProcessing
# #### Data is in two data frames so we merge them to make one dataframe
# Note: two dataframes has same column names

# In[4]:

urls = legitimate_urls.append(phishing_urls)


# In[5]:


urls.head(5)

# In[6]:

print(len(urls))
print(urls.columns)
# #### Removing Unnecessary columns

# In[7]:

urls = urls.drop(urls.columns[[0,3,5]],axis=1)
print(urls.columns)

urls = urls.sample(frac=1).reset_index(drop=True)
# #### Removing class variable from the dataset
urls_without_labels = urls.drop('label',axis=1)
urls_without_labels.columns
labels = urls['label']
#labels

# #### splitting the data into train data and test data
import random
random.seed(7)
from sklearn.model_selection import train_test_split
data_train, data_test, labels_train, labels_test = train_test_split(urls_without_labels, labels, test_size=0.20, random_state=100)
print(len(data_train),len(data_test),len(labels_train),len(labels_test))
print(labels_train.value_counts())
print(labels_test.value_counts())

from sklearn.linear_model import LogisticRegression
LRmodel = LogisticRegression()
LRmodel.fit(data_train,labels_train)

from sklearn.tree import DecisionTreeClassifier
DTmodel = DecisionTreeClassifier(random_state=0)
DTmodel.fit(data_train,labels_train)

from sklearn.ensemble import VotingClassifier
esemble=VotingClassifier(estimators=[('Decision Tree',DTmodel ), ('L R', LRmodel)],voting='soft', weights=[1,1]).fit(data_train,labels_train)

#import pickle
#filename = 'finalized_model.sav'
#with open(filename,'wb') as f:
#    pickle.dump(LRmodel, f)
#f.close()

